import sqlite3

def create_database():
    # Conecta ao banco de dados (cria o arquivo se não existir)
    conn = sqlite3.connect('database.db')
    # Cria a tabela 'items'
    conn.execute('''
        CREATE TABLE IF NOT EXISTS items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()
    print("Banco de dados criado com sucesso!")

if __name__ == "__main__":
    create_database()

   